# AppDynamics relay demo for corporate laptop

This package gives you a local Python relay plus a single HTML page.

## What it does

- runs a local server on `http://127.0.0.1:8000`
- serves the HTML form
- posts AppDynamics OAuth and metric requests through Python instead of the browser
- reads `EIMID` from the Metadata tab
- matches AppDynamics application name to EIMID exactly
- loads `Overall Application Performance` metrics into a dropdown
- populates:
  - Baseline Avg Volumes
  - Baseline Peak Volumes
  - Max System Capacity
- colors those fields by decision:
  - green = accepted
  - orange = overridden
  - blue = manual

## Files

- `index.html` - UI
- `relay.py` - local relay

## Run it

### Windows PowerShell

```powershell
cd path\to\corp_laptop_appd_demo
$env:APPD_PROXY="http://your-proxy-host:port"
python relay.py
```

If your corporate controller uses a cert chain your laptop does not trust and you only need a quick test:

```powershell
$env:APPD_VERIFY_SSL="false"
python relay.py
```

### macOS / Linux

```bash
cd /path/to/corp_laptop_appd_demo
export APPD_PROXY="http://your-proxy-host:port"
python3 relay.py
```

Optional quick test with SSL verification disabled:

```bash
export APPD_VERIFY_SSL=false
python3 relay.py
```

Then open:

```text
http://127.0.0.1:8000
```

## In the page

1. Enter Controller URL
2. Enter Client ID
3. Enter Client Secret
4. Confirm the EIMID in Metadata
5. Click **Load Metrics**
6. Choose a metric from the dropdown
7. Click **Populate Values**

## Notes

- The relay expects the applications API to return XML like:
  - `applications > application > id`
  - `applications > application > name`
- Matching is exact by application `name == EIMID`
- The selected metric is fetched with `rollup=false` and `time-range-type=BEFORE_NOW`
- Avg is calculated from returned datapoints, Peak is the max datapoint, and Max System Capacity is set to the same max datapoint for this demo

## Quick sanity check

Open this after the relay starts:

```text
http://127.0.0.1:8000/health
```

It will show whether the relay sees your proxy setting.
