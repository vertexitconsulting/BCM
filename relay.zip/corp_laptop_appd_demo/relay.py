#!/usr/bin/env python3
import json
import os
import ssl
import sys
import urllib.parse
import urllib.request
import urllib.error
import xml.etree.ElementTree as ET
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

HOST = '127.0.0.1'
PORT = 8000
BASE = Path(__file__).resolve().parent
INDEX = BASE / 'index.html'
APPD_PROXY = os.environ.get('APPD_PROXY', '').strip()
APPD_VERIFY_SSL = os.environ.get('APPD_VERIFY_SSL', 'true').lower() not in ('0','false','no')


def json_bytes(obj, status=200):
    return status, {'Content-Type': 'application/json; charset=utf-8'}, json.dumps(obj).encode('utf-8')


def build_opener():
    handlers = []
    if APPD_PROXY:
        handlers.append(urllib.request.ProxyHandler({'http': APPD_PROXY, 'https': APPD_PROXY}))
    else:
        handlers.append(urllib.request.ProxyHandler())
    if not APPD_VERIFY_SSL:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        handlers.append(urllib.request.HTTPSHandler(context=ctx))
    return urllib.request.build_opener(*handlers)


def http_request(method, url, headers=None, data=None):
    opener = build_opener()
    req = urllib.request.Request(url, data=data, headers=headers or {}, method=method)
    try:
        with opener.open(req, timeout=60) as resp:
            return resp.getcode(), resp.headers, resp.read()
    except urllib.error.HTTPError as e:
        body = e.read().decode('utf-8', 'replace') if hasattr(e, 'read') else ''
        raise RuntimeError(f'{method} {url} failed with {e.code}: {body[:500]}')
    except Exception as e:
        raise RuntimeError(f'{method} {url} failed: {e}')


def token(controller_url, client_id, client_secret):
    url = controller_url.rstrip('/') + '/controller/api/oauth/access_token'
    body = urllib.parse.urlencode({
        'grant_type': 'client_credentials',
        'client_id': client_id,
        'client_secret': client_secret,
    }).encode('utf-8')
    status, headers, raw = http_request('POST', url, {'Content-Type': 'application/x-www-form-urlencoded'}, body)
    data = json.loads(raw.decode('utf-8'))
    return data.get('access_token') or data.get('token') or data.get('accessToken')


def get_applications(controller_url, bearer):
    url = controller_url.rstrip('/') + '/controller/rest/applications'
    status, headers, raw = http_request('GET', url, {'Authorization': f'Bearer {bearer}', 'Accept': 'application/xml'})
    root = ET.fromstring(raw)
    apps = []
    for app in root.findall('.//application'):
        apps.append({
            'id': (app.findtext('id') or '').strip(),
            'name': (app.findtext('name') or '').strip(),
            'accountGuid': (app.findtext('accountGuid') or '').strip(),
        })
    return apps


def match_application(apps, eimid):
    target = (eimid or '').strip().lower()
    for app in apps:
        if app['name'].strip().lower() == target:
            return app
    return None


def get_metric_hierarchy(controller_url, bearer, app_name, metric_path='Overall Application Performance'):
    q = urllib.parse.urlencode({'metric-path': metric_path, 'output': 'JSON'})
    url = controller_url.rstrip('/') + '/controller/rest/applications/' + urllib.parse.quote(app_name, safe='') + '/metrics?' + q
    status, headers, raw = http_request('GET', url, {'Authorization': f'Bearer {bearer}', 'Accept': 'application/json'})
    text = raw.decode('utf-8', 'replace').strip()
    metrics = []
    if text.startswith('{') or text.startswith('['):
        data = json.loads(text)
        items = data.get('metricItems') if isinstance(data, dict) else data
        for item in items or []:
            name = (item.get('name') or '').strip()
            if name:
                metrics.append(metric_path + '|' + name)
    else:
        root = ET.fromstring(raw)
        for item in root.findall('.//metric-item'):
            name = (item.findtext('name') or '').strip()
            if name:
                metrics.append(metric_path + '|' + name)
    return metrics


def get_metric_data(controller_url, bearer, app_name, metric_path, duration_mins):
    q = urllib.parse.urlencode({
        'metric-path': metric_path,
        'time-range-type': 'BEFORE_NOW',
        'duration-in-mins': str(duration_mins),
        'rollup': 'false',
        'output': 'JSON',
    })
    url = controller_url.rstrip('/') + '/controller/rest/applications/' + urllib.parse.quote(app_name, safe='') + '/metric-data-v2?' + q
    status, headers, raw = http_request('GET', url, {'Authorization': f'Bearer {bearer}', 'Accept': 'application/json'})
    text = raw.decode('utf-8', 'replace').strip()
    values = []
    if text.startswith('{') or text.startswith('['):
        data = json.loads(text)
        rows = data if isinstance(data, list) else data.get('metric-data-v2') or data.get('metricData') or data.get('metric-data') or []
        if isinstance(rows, dict):
            rows = [rows]
        for row in rows:
            for mv in row.get('metricValues', []) or row.get('metric-values', []) or []:
                val = mv.get('value', mv.get('current', mv.get('sum')))
                if val is not None:
                    try:
                        values.append(float(val))
                    except Exception:
                        pass
    else:
        root = ET.fromstring(raw)
        for mv in root.findall('.//metric-value') + root.findall('.//metric-value-v2'):
            val = mv.findtext('value') or mv.findtext('current') or mv.findtext('sum')
            if val is not None:
                try:
                    values.append(float(val))
                except Exception:
                    pass
    if not values:
        raise RuntimeError('No datapoints returned for the selected metric and window.')
    avg = round(sum(values)/len(values), 2)
    peak = round(max(values), 2)
    maxv = peak
    return {'avg': avg, 'peak': peak, 'max': maxv, 'points': len(values), 'metricPath': metric_path, 'metricUrl': url}


class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path in ('/', '/index.html'):
            data = INDEX.read_bytes()
            self.send_response(200)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.send_header('Content-Length', str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return
        if self.path == '/health':
            status, headers, data = json_bytes({'ok': True, 'proxy': APPD_PROXY or None, 'verify_ssl': APPD_VERIFY_SSL})
            self.send_response(status)
            for k, v in headers.items(): self.send_header(k, v)
            self.end_headers()
            self.wfile.write(data)
            return
        self.send_response(404)
        self.end_headers()

    def do_POST(self):
        length = int(self.headers.get('Content-Length', '0') or '0')
        raw = self.rfile.read(length) if length else b'{}'
        try:
            body = json.loads(raw.decode('utf-8') or '{}')
        except Exception:
            body = {}
        try:
            if self.path == '/api/appd/discover':
                result = self.handle_discover(body)
                status, headers, data = json_bytes(result)
            elif self.path == '/api/appd/metric-data':
                result = self.handle_metric_data(body)
                status, headers, data = json_bytes(result)
            else:
                status, headers, data = json_bytes({'error': 'Not found'}, 404)
        except Exception as e:
            status, headers, data = json_bytes({'error': str(e)}, 500)
        self.send_response(status)
        for k, v in headers.items(): self.send_header(k, v)
        self.end_headers()
        self.wfile.write(data)

    def handle_discover(self, body):
        controller = (body.get('controllerUrl') or '').strip()
        client_id = (body.get('clientId') or '').strip()
        client_secret = (body.get('clientSecret') or '').strip()
        eimid = (body.get('eimid') or '').strip()
        if not all([controller, client_id, client_secret, eimid]):
            raise RuntimeError('controllerUrl, clientId, clientSecret, and eimid are required.')
        bearer = token(controller, client_id, client_secret)
        if not bearer:
            raise RuntimeError('Token response did not include an access token.')
        apps = get_applications(controller, bearer)
        app = match_application(apps, eimid)
        if not app:
            names = ', '.join(a['name'] for a in apps[:25])
            raise RuntimeError(f'No application matched EIMID "{eimid}" by exact name. First application names returned: {names}')
        metrics = get_metric_hierarchy(controller, bearer, app['name'])
        return {'applicationId': app['id'], 'applicationName': app['name'], 'metrics': metrics}

    def handle_metric_data(self, body):
        controller = (body.get('controllerUrl') or '').strip()
        client_id = (body.get('clientId') or '').strip()
        client_secret = (body.get('clientSecret') or '').strip()
        eimid = (body.get('eimid') or '').strip()
        metric_path = (body.get('metricPath') or '').strip()
        duration_mins = int(body.get('durationMins') or 90)
        if not all([controller, client_id, client_secret, eimid, metric_path]):
            raise RuntimeError('controllerUrl, clientId, clientSecret, eimid, and metricPath are required.')
        bearer = token(controller, client_id, client_secret)
        if not bearer:
            raise RuntimeError('Token response did not include an access token.')
        apps = get_applications(controller, bearer)
        app = match_application(apps, eimid)
        if not app:
            raise RuntimeError(f'No application matched EIMID "{eimid}" by exact name.')
        return get_metric_data(controller, bearer, app['name'], metric_path, duration_mins)

    def log_message(self, format, *args):
        sys.stdout.write('%s - - [%s] %s\n' % (self.address_string(), self.log_date_time_string(), format%args))


if __name__ == '__main__':
    print(f'Serving on http://{HOST}:{PORT}')
    if APPD_PROXY:
        print(f'Using proxy: {APPD_PROXY}')
    else:
        print('No APPD_PROXY set; direct outbound connections will be attempted.')
    if not APPD_VERIFY_SSL:
        print('SSL verification disabled via APPD_VERIFY_SSL=false')
    server = ThreadingHTTPServer((HOST, PORT), Handler)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
