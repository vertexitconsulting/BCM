# AppDynamics corporate laptop demo

Run:
- Set proxy if needed: `APPD_PROXY=http://proxy:port`
- Optional: `APPD_VERIFY_SSL=false`
- Start: `python relay.py`
- Open: `http://127.0.0.1:8000`

This regenerated package is based on the user-provided previous version and keeps the same UI, while updating the relay to:
- match EIM ID from `<description>` by stripping `EIM:`
- try metric lookup by app name first, then app id fallback
- try metric data endpoints in multiple common forms:
  - `/metric-data-v2` by app id
  - `/metric-data` by app id
  - `/metric-data-v2` by app name
  - `/metric-data` by app name
- preserve the 1/3/6 month and custom range window translation
