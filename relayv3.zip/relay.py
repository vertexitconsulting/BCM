
import json, os, re
from http.server import BaseHTTPRequestHandler, HTTPServer
import requests
import xml.etree.ElementTree as ET
from urllib.parse import quote

PROXY = os.environ.get("APPD_PROXY")
VERIFY_SSL = os.environ.get("APPD_VERIFY_SSL", "true").lower() != "false"

def json_response(handler, data, status=200):
    handler.send_response(status)
    handler.send_header("Content-Type", "application/json")
    handler.end_headers()
    handler.wfile.write(json.dumps(data).encode())

def get_token(controller, client_id, client_secret):
    url = f"{controller}/controller/api/oauth/access_token"
    data = {
        "grant_type": "client_credentials",
        "client_id": client_id,
        "client_secret": client_secret
    }
    proxies = {"http": PROXY, "https": PROXY} if PROXY else None
    r = requests.post(url, data=data, proxies=proxies, verify=VERIFY_SSL)
    r.raise_for_status()
    return r.json()["access_token"]

def get_applications_xml(controller, token):
    url = f"{controller}/controller/rest/applications"
    headers = {"Authorization": f"Bearer {token}"}
    proxies = {"http": PROXY, "https": PROXY} if PROXY else None
    r = requests.get(url, headers=headers, proxies=proxies, verify=VERIFY_SSL)
    r.raise_for_status()
    return r.text

def parse_apps(xml_text):
    root = ET.fromstring(xml_text)
    apps = []
    for a in root.findall(".//application"):
        apps.append({
            "id": (a.findtext("id") or "").strip(),
            "name": (a.findtext("name") or "").strip(),
            "description": (a.findtext("description") or "").strip()
        })
    return apps

def extract_eim(desc):
    m = re.search(r"EIM\s*:\s*(\d+)", desc or "", re.IGNORECASE)
    return m.group(1) if m else ""

def find_app(apps, eimid):
    target = ''.join(filter(str.isdigit, str(eimid)))
    for a in apps:
        if extract_eim(a["description"]) == target:
            return a
    return None

class Handler(BaseHTTPRequestHandler):
    def do_POST(self):
        if self.path == "/api/resolve":
            length = int(self.headers.get("Content-Length"))
            body = json.loads(self.rfile.read(length))
            controller = body["controller"]
            cid = body["clientId"]
            sec = body["clientSecret"]
            eimid = body["eimid"]

            token = get_token(controller, cid, sec)
            xml = get_applications_xml(controller, token)
            apps = parse_apps(xml)
            app = find_app(apps, eimid)

            if not app:
                return json_response(self, {"ok": False, "msg": "No match"}, 404)

            return json_response(self, {"ok": True, "app": app})

def run():
    server = HTTPServer(("127.0.0.1", 8000), Handler)
    print("Running on http://127.0.0.1:8000")
    server.serve_forever()

if __name__ == "__main__":
    run()
