#!/usr/bin/env python
import json
import os
import re
import ssl
import sys
from datetime import datetime, timedelta
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import quote, urlencode, urlparse, parse_qs
from urllib.request import Request, build_opener, ProxyHandler, HTTPSHandler
import urllib.request
import xml.etree.ElementTree as ET

BASE_DIR = Path(__file__).resolve().parent
HOST = '127.0.0.1'
PORT = 8000
APPD_PROXY = os.environ.get('APPD_PROXY', '').strip()
VERIFY_SSL = os.environ.get('APPD_VERIFY_SSL', 'true').strip().lower() not in ('0', 'false', 'no')


def json_response(handler, payload, status=200):
    data = json.dumps(payload).encode('utf-8')
    handler.send_response(status)
    handler.send_header('Content-Type', 'application/json; charset=utf-8')
    handler.send_header('Content-Length', str(len(data)))
    handler.end_headers()
    handler.wfile.write(data)


def read_json(handler):
    length = int(handler.headers.get('Content-Length', '0') or '0')
    raw = handler.rfile.read(length) if length else b'{}'
    if not raw:
        return {}
    return json.loads(raw.decode('utf-8'))


def clean_controller(url):
    url = (url or '').strip().rstrip('/')
    if not url:
        raise ValueError('Controller URL is required.')
    if not url.startswith('http://') and not url.startswith('https://'):
        url = 'https://' + url
    return url


def make_opener():
    handlers = []
    if APPD_PROXY:
        handlers.append(ProxyHandler({'http': APPD_PROXY, 'https': APPD_PROXY}))
    else:
        handlers.append(ProxyHandler())
    if VERIFY_SSL:
        context = ssl.create_default_context()
    else:
        context = ssl._create_unverified_context()
    handlers.append(HTTPSHandler(context=context))
    return build_opener(*handlers)


OPENER = make_opener()


def http_request(url, method='GET', headers=None, data=None):
    req = Request(url, data=data, headers=headers or {}, method=method)
    try:
        with OPENER.open(req, timeout=60) as resp:
            return resp.getcode(), resp.read(), dict(resp.headers)
    except HTTPError as e:
        body = e.read().decode('utf-8', errors='replace')
        raise RuntimeError(f'HTTP {e.code} from AppDynamics: {body[:500]}')
    except URLError as e:
        raise RuntimeError(f'Network error contacting AppDynamics: {e}')


def get_token(controller_url, client_id, client_secret):
    url = clean_controller(controller_url) + '/controller/api/oauth/access_token'
    payload = urlencode({
        'grant_type': 'client_credentials',
        'client_id': client_id,
        'client_secret': client_secret,
    }).encode('utf-8')
    status, body, _ = http_request(url, method='POST', headers={'Content-Type': 'application/x-www-form-urlencoded'}, data=payload)
    try:
        data = json.loads(body.decode('utf-8'))
    except Exception:
        raise RuntimeError(f'Unexpected token response ({status}): {body[:500]!r}')
    token = data.get('access_token')
    if not token:
        raise RuntimeError(f'No access_token in token response: {data}')
    return token


def get_applications_xml(controller_url, token):
    url = clean_controller(controller_url) + '/controller/rest/applications'
    status, body, _ = http_request(url, headers={'Authorization': f'Bearer {token}', 'Accept': 'application/xml'})
    return body.decode('utf-8', errors='replace')


def parse_applications_xml(xml_text):
    try:
        root = ET.fromstring(xml_text)
    except ET.ParseError as e:
        raise RuntimeError(f'Unable to parse applications XML: {e}')
    applications = []
    for app in root.findall('.//application'):
        applications.append({
            'id': (app.findtext('id') or '').strip(),
            'name': (app.findtext('name') or '').strip(),
            'description': (app.findtext('description') or '').strip(),
            'accountGuid': (app.findtext('accountGuid') or '').strip(),
        })
    return applications


def extract_numeric_eim(description):
    desc = (description or '').strip()
    if not desc:
        return ''
    match = re.search(r'EIM\s*:\s*(\d+)', desc, flags=re.IGNORECASE)
    if match:
        return match.group(1)
    desc = re.sub(r'(?i)eim\s*:', '', desc)
    return ''.join(ch for ch in desc if ch.isdigit())


def find_app_by_eimid(applications, eimid):
    target = ''.join(ch for ch in str(eimid).strip() if ch.isdigit())
    if not target:
        return None
    for app in applications:
        if extract_numeric_eim(app.get('description', '')) == target:
            return app
    return None


def get_metrics_list(controller_url, token, app_name):
    app_name_enc = quote(app_name, safe='')
    params = urlencode({'metric-path': 'Overall Application Performance', 'output': 'JSON'})
    url = clean_controller(controller_url) + f'/controller/rest/applications/{app_name_enc}/metrics?{params}'
    _, body, _ = http_request(url, headers={'Authorization': f'Bearer {token}', 'Accept': 'application/json'})
    try:
        parsed = json.loads(body.decode('utf-8'))
    except Exception:
        raise RuntimeError(f'Unable to parse metrics list JSON: {body[:500]!r}')
    items = parsed if isinstance(parsed, list) else parsed.get('items', parsed.get('metric', [])) if isinstance(parsed, dict) else []
    metrics = []
    for item in items:
        metric_path = item.get('metricPath') or item.get('metric-path') or item.get('path')
        if metric_path:
            metrics.append({'label': metric_path.split('|')[-1], 'value': metric_path})
    dedup = []
    seen = set()
    for m in metrics:
        if m['value'] not in seen:
            dedup.append(m)
            seen.add(m['value'])
    return dedup


def parse_metric_values(parsed):
    values = []
    metric_items = parsed if isinstance(parsed, list) else [parsed]
    for item in metric_items:
        mvals = item.get('metricValues') or item.get('metric-values') or []
        for mv in mvals:
            value = mv.get('value')
            if value is None:
                continue
            try:
                values.append(float(value))
            except Exception:
                pass
    return values


def build_window_params(window_key, custom_start=None, custom_end=None):
    if window_key == '1m':
        return {'time-range-type': 'BEFORE_NOW', 'duration-in-mins': str(60 * 24 * 30)}
    if window_key == '3m':
        return {'time-range-type': 'BEFORE_NOW', 'duration-in-mins': str(60 * 24 * 90)}
    if window_key == '6m':
        return {'time-range-type': 'BEFORE_NOW', 'duration-in-mins': str(60 * 24 * 180)}
    if window_key == 'custom':
        if not custom_start or not custom_end:
            raise RuntimeError('Custom range requires start and end dates.')
        start_dt = datetime.fromisoformat(custom_start + 'T00:00:00')
        end_dt = datetime.fromisoformat(custom_end + 'T23:59:59')
        return {
            'time-range-type': 'BETWEEN_TIMES',
            'start-time': str(int(start_dt.timestamp() * 1000)),
            'end-time': str(int(end_dt.timestamp() * 1000)),
        }
    return {'time-range-type': 'BEFORE_NOW', 'duration-in-mins': str(60 * 24 * 90)}


def get_metric_data(controller_url, token, app_id, app_name, metric_path, window_key, custom_start=None, custom_end=None):
    app_id_enc = quote(str(app_id), safe='')
    app_name_enc = quote(app_name, safe='')
    params = {'metric-path': metric_path, 'output': 'JSON'}
    params.update(build_window_params(window_key, custom_start, custom_end))
    qs = urlencode(params)
    data_url = clean_controller(controller_url) + f'/controller/rest/applications/{app_id_enc}/metric-data?{qs}'
    browser_metric_url = clean_controller(controller_url) + f'/controller/rest/applications/{app_name_enc}/metric-data?{qs}'
    _, body, _ = http_request(data_url, headers={'Authorization': f'Bearer {token}', 'Accept': 'application/json'})
    try:
        parsed = json.loads(body.decode('utf-8'))
    except Exception:
        raise RuntimeError(f'Unable to parse metric data JSON: {body[:500]!r}')
    values = parse_metric_values(parsed)
    if not values:
        return {
            'avg': '',
            'peak': '',
            'max': '',
            'confidencePct': 0,
            'confidenceBand': 'Low',
            'metricUrl': browser_metric_url,
            'metricDataUrl': data_url,
            'rawCount': 0,
        }
    avg = round(sum(values) / len(values), 2)
    peak = round(max(values), 2)
    max_v = peak
    # Confidence based on data coverage only for PoC.
    raw_count = len(values)
    confidence_pct = min(100, raw_count)
    if confidence_pct < 30:
        band = 'Low'
    elif confidence_pct < 60:
        band = 'Medium'
    else:
        band = 'High'
    return {
        'avg': avg,
        'peak': peak,
        'max': max_v,
        'confidencePct': confidence_pct,
        'confidenceBand': band,
        'metricUrl': browser_metric_url,
        'metricDataUrl': data_url,
        'rawCount': raw_count,
    }


class Handler(BaseHTTPRequestHandler):
    def _serve_file(self, path, content_type='text/html; charset=utf-8'):
        try:
            data = Path(path).read_bytes()
        except FileNotFoundError:
            self.send_error(404)
            return
        self.send_response(200)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path in ('/', '/index.html'):
            return self._serve_file(BASE_DIR / 'index.html')
        if parsed.path == '/api/health':
            return json_response(self, {'ok': True, 'proxyConfigured': bool(APPD_PROXY), 'verifySsl': VERIFY_SSL})
        self.send_error(404)

    def do_POST(self):
        try:
            if self.path == '/api/resolve-app':
                body = read_json(self)
                controller = body.get('controllerUrl', '')
                client_id = body.get('clientId', '')
                client_secret = body.get('clientSecret', '')
                eimid = body.get('eimid', '')
                token = get_token(controller, client_id, client_secret)
                xml_text = get_applications_xml(controller, token)
                applications = parse_applications_xml(xml_text)
                app = find_app_by_eimid(applications, eimid)
                if not app:
                    return json_response(self, {'ok': False, 'message': f'No application found where description contains EIM:{eimid}.'}, status=404)
                metrics = get_metrics_list(controller, token, app['name'])
                return json_response(self, {'ok': True, 'application': app, 'metrics': metrics})
            if self.path == '/api/fetch-metric':
                body = read_json(self)
                controller = body.get('controllerUrl', '')
                client_id = body.get('clientId', '')
                client_secret = body.get('clientSecret', '')
                app_id = body.get('appId', '')
                app_name = body.get('appName', '')
                metric_path = body.get('metricPath', '')
                window_key = body.get('selectionWindow', '3m')
                custom_start = body.get('customStart')
                custom_end = body.get('customEnd')
                token = get_token(controller, client_id, client_secret)
                data = get_metric_data(controller, token, app_id, app_name, metric_path, window_key, custom_start, custom_end)
                return json_response(self, {'ok': True, **data})
            self.send_error(404)
        except Exception as e:
            return json_response(self, {'ok': False, 'message': str(e)}, status=500)


def main():
    httpd = HTTPServer((HOST, PORT), Handler)
    proxy_note = APPD_PROXY if APPD_PROXY else 'none'
    ssl_note = 'enabled' if VERIFY_SSL else 'disabled'
    print(f'Server running on http://{HOST}:{PORT}')
    print(f'Proxy: {proxy_note}')
    print(f'SSL verification: {ssl_note}')
    httpd.serve_forever()


if __name__ == '__main__':
    main()
