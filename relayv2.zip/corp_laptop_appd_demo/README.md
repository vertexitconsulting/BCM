# AppDynamics corporate laptop demo

## Files
- `index.html` — browser UI
- `relay.py` — local Python relay, no third-party packages required

## Run
PowerShell:

```powershell
cd path\to\corp_laptop_appd_demo
$env:APPD_PROXY="http://your-proxy-host:port"
python relay.py
```

If SSL inspection breaks the call:

```powershell
$env:APPD_VERIFY_SSL="false"
python relay.py
```

Open:

```text
http://127.0.0.1:8000
```

## What changed in this version
- EIM ID is numeric and is matched against `<application><id>` in the AppDynamics applications XML
- the corresponding application `<name>` is shown in the form
- added dummy Source dropdown: AppD, Opentext, Splunk
- selection window options: 1 Month, 3 Months, 6 Months, Custom range
- custom range shows start/end date fields
- metric URL now shows the full URL used for metric data
- low confidence is red, medium is amber, high is green
- Populate values can be run repeatedly after changing metric or window
- medium band is fixed to 30–59%, high is 60–100%

## AppDynamics assumptions
- token: `POST /controller/api/oauth/access_token`
- applications list returns XML
- metrics list returns JSON for `Overall Application Performance`
- metric data returns JSON from `/controller/rest/applications/{appName}/metric-data`

If your controller needs a different metric-data path or parameters, edit `relay.py` in:
- `get_metrics_list()`
- `get_metric_data()`
